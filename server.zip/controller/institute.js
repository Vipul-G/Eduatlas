const joi = require('@hapi/joi');

const Institute = require('../model/institute.model');

const instituteSchema = joi.object({
    basicInfo: joi.object({
        name: joi.string().required(),
        contactNumber: joi.number().required()
    })
});

exports.addInstitute = async (req, res, next) => {

    const {error, value} = instituteSchema.validate(req.body);
    console.log('Req.body', req.body, value);
    if(error) {
        console.log(error);
        res.status(400).json({
            message: 'Insufficient/Wrong parameters provided'
        });
    }
    let institute;
    try {
        institute = await Institute.create(req.body);
    } catch(error) {
        console.log('Catched - ',error)
        res.status(500).json({ "message": 'Internal server error' })
    }

    console.log('institute - ', institute);

    res.end();

};
