const joi = require('@hapi/joi');

function checkPhone(value, helpers) {

    if (value.toString().length !== 10 || value == undefined) {
      return helpers.error('Incorrect Phone number')
    }
  
    return value;
  
}

exports.schema = {
    signup: joi.object({
      name: joi.string()
        .alphanum()
        .min(3)
        .max(30)
        .required(),
    
      email: joi.string()
        .email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } })
        .required(),
    
      phone: joi.number().custom(checkPhone, 'Phone number validator').required(),
    
      password: joi.string()
        .pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')),
  
      role: joi.string().required()
  
    }),
  
    login: joi.object({
      phone: joi.custom(checkPhone, 'Phone number validator').required(),
  
      password: joi.string()
        .pattern(new RegExp('^[a-zA-Z0-9]{3,30}$'))
  
    })
  }