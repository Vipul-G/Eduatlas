const instituteRouter = require('express').Router();
const instituteController = require('../controller/institute');

instituteRouter.post('/addInstitute', instituteController.addInstitute);

module.exports = instituteRouter; 